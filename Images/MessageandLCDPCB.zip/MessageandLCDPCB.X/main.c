 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "ssd1306.h"
#include "ssd1306font.h"
//#include "ssd1306.h"
//#include "ssd1306font.h"

uint16_t ms=0;
uint16_t sec=0;


void timer_callback(void)
{
    ms++;
    if (ms>1000) 
    {
        ms -= 1000;
        sec++;
    //    IO_RA2_Toggle();
    }
}

void eusart_callback(void)
{
//    ms++;
}

uint8_t send_message(char * my_message){
    printf("%s",my_message);
    return 1;
}
        

#define BUFSIZE 4
#define MSGSIZE 64
#define TEAMSIZE 4
#define MSGTESTSIZE 64
#define MSGTESTCHAR 0

const char my_id='f';
const char team_ids[TEAMSIZE+1] = "fhlm";
const char bc = 'X';
char buffer_in[BUFSIZE+1];
char message_in[MSGSIZE+1];
char message_out[MSGSIZE+1];
char mode = '0', LB = '1', RB = '1';
char sensor1[5] = "0000", sensor2[5] = "0000"; // 4 digits + null; 
int sensor1_idx = 0;
int sensor2_idx = 0;
//int s1 = 450, s2 = 7000, s3 = 500, s4 = 6, mv = 2500;
int flag = 1, count = 0;
//char stream_in[]="-----AZcb34567890YB-----------AZcd34567890YB--AZed34567890YB--AZdz34567890YB---AZed1234567890123456789012345678901234567890123456789012345678YB-";
//char read_char(void){
//    static int ii=0;
//    char c = stream_in[ii];
//    ii++;
//    if (ii>=(sizeof stream_in)-1)
//    {ii=0;}
//    return c;
//}

void fill_string(char * mystring,char value,unsigned int size){
    for (int ii=0;ii<size;ii++){
        mystring[ii]=value;
    }
}

unsigned int find_char(char * mystring, char value,unsigned int size){
    char c=0;
    for (int ii=0;ii<size;ii++){
        c= mystring[ii];
//        printf("%c,%c;",value,mystring[ii]);
        if (c==value){
            return 1;
        }
    }
    return 0;
}

void handle_message(unsigned int ii){
    message_in[ii-2]=0;
   ssd1306_clear();
   ssd1306_draw_string(0,0,"Solar Tracker Data");
   if (mode=='0'){
    IO_RB1_SetLow();
    ssd1306_draw_string(3,3,"Mode: Automatic");}
    if (mode=='1'){
    IO_RB1_SetHigh();
    ssd1306_draw_string(3,3,"Mode: Manual");}
   
   //sensor extract and oled: 
   for (int i = 0; i < MSGSIZE-5; i++) {
        if (message_in[i] == 'S' && message_in[i+1] == '1') {
            sensor1[0] = message_in[i+2];
            sensor1[1] = message_in[i+3];
            sensor1[2] = message_in[i+4];
            sensor1[3] = message_in[i+5];
            sensor1[4] = '\0';
        }
        if (message_in[i] == 'S' && message_in[i+1] == '2') {
            sensor2[0] = message_in[i+2];
            sensor2[1] = message_in[i+3];
            sensor2[2] = message_in[i+4];
            sensor2[3] = message_in[i+5];
            sensor2[4] = '\0';
        }
    }

    
    ssd1306_draw_string(0,5,"Sensor 1:");
    ssd1306_draw_string(70, 5, sensor1);
    ssd1306_draw_string(0,7,"Sensor 2:");
    ssd1306_draw_string(70, 7, sensor2); 
}

//ssd1306_draw_string(0, 5, sensor1);  // Display the single character as a string; 
    


int main(void)
{
//    ssd1306_clear();
    char c=0;
    unsigned int buffer_ii=0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii=0;
    unsigned int message_last_ii=0;
    buffer_in[BUFSIZE]=0;
    message_in[MSGSIZE]=0;
    unsigned int message_incoming=0;
    fill_string(buffer_in,'a',BUFSIZE);
    fill_string(message_in,'_',MSGSIZE);
    message_in[MSGTESTSIZE]=MSGTESTCHAR;

    uint16_t ms_last=0;
    uint16_t sec_last=0;
    SYSTEM_Initialize();
    //ssd1306_init();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 
    TMR1_Initialize();
    TMR1_Start();
    //TMR1_TMRInterruptEnable();

    TMR1_OverflowCallbackRegister(timer_callback);

    EUSART1_Initialize();
    EUSART1_Enable();
    
    ssd1306_init();
//    EUSART1_TransmitEnable();
//    EUSART1_ReceiveEnable();
//    EUSART1_TransmitInterruptEnable();
//    EUSART1_ReceiveInterruptEnable();
//    
//    UART1_RxCompleteCallbackRegister(eusart_callback);

//sprintf(message_out,"AZNKK2YB");
//    printf("%lu", sizeof buffer_in);
    
while (1)
{
 //ssd1306_draw_string(0, 3, "     Hello There     "); 
     if(IO_RA2_GetValue()==0){
        LB = '1';
    }
    if(IO_RA2_GetValue()==1){
        LB = '0';
    }
    if(IO_RA3_GetValue()==0){
        RB = '1';
    }
    if(IO_RA3_GetValue()==1){
        RB = '0';
    }
                
    if (EUSART1_IsRxReady())
    {
        c = EUSART1_Read();
        if(c == '\0')
        {
            count+=1;
        }
        else
        {
            count = 0;
        }
        buffer_in[buffer_ii] = c;

        // Message Start Detected
        if (buffer_in[buffer_last_ii] == 'A' && c == 'Z')
        {
            message_incoming = 1;
            message_ii = 0;
            fill_string(message_in, '_', MSGSIZE);
            message_in[0] = 'A';
            message_ii = 1;
        }

        // Store Incoming Message
        if (message_incoming)
        {
            message_in[message_ii++] = c;
            
            if (message_ii == 4)
            {
                if(!(find_char(team_ids,buffer_in[buffer_last_ii],TEAMSIZE)))
                {
                    printf("AZfmPIC:SenderNotinTeamYB");
                    message_incoming = 0;
                    fill_string(message_in,'_',MSGSIZE);
                }
                if (message_in[3] == bc)
                {
                    printf("AZfmPIC:BroadcastingYB");
                    flag = 0;
                }
                else if (!(find_char(team_ids,c,TEAMSIZE)))
                {
                    printf("AZfmPIC:RecieverNotinTeamYB");
                    message_incoming = 0;
                    fill_string(message_in,'_',MSGSIZE);
                }
                if ((message_in[2] == my_id))
                {
                    printf("AZfmPIC:DuplicateMessageDeletedYB");
                    message_incoming = 0;
                    fill_string(message_in,'_',MSGSIZE);
                }
                
            }
          
            // Message End Detected
            if (c == 'B' && buffer_in[buffer_last_ii] == 'Y')
            {
                message_incoming = 0;
                message_in[message_ii] = '\0'; // Null-terminate the message
                    
    
                handle_message(message_ii);

                // Format the response message
                if (flag == 1)
                {
                    sprintf(message_out, "AZfmM%cL%cR%cYB", mode, LB, RB);
                    
                }
                else
                {
                    for (int i = 0; message_out[i] != '\0'; i++)
                    {
                        message_out[i] = message_in[i];
                    }
                }
                    // Send the response
                    for (int i = 0; message_out[i] != '\0'; i++)
                        {
                            while (!EUSART1_IsTxReady()); // Wait until ready
                            EUSART1_Write(message_out[i]);
                        }
            }

            // Prevent Buffer Overflow
            if (message_ii >= MSGSIZE)
            {
                printf("AZfmPIC:messagetoolargeYB");
                message_incoming = 0;
            }
            
        }

        // Update mode, LB, and RB when detected
        if (buffer_in[buffer_last_ii] == 'M')
        {
            if((buffer_in[buffer_ii] == '0' || buffer_in[buffer_ii] == '1'))
            {
                mode = buffer_in[buffer_ii];
                 if (mode=='1'){
                    IO_RB1_SetHigh();
                    //ssd1306_draw_string(3,3,"Auto");
                }
                if (mode=='0'){
                    IO_RB1_SetLow();
                //ssd1306_draw_string(3,3,"Manual");
                }
            }
            else
            {
                printf("AZfmPIC:BadDataForModeYB");
                message_incoming = 0;
                fill_string(message_in,'_',MSGSIZE);
            }
   
        }
        if (buffer_in[buffer_last_ii] == 'L')
        {
            if((buffer_in[buffer_ii] == '0' || buffer_in[buffer_ii] == '1'))
            {
                LB = buffer_in[buffer_ii];
            }
            else
            {
                printf("AZfmPIC:BadDataForLeftButtonYB");
                message_incoming = 0;
                fill_string(message_in,'_',MSGSIZE);
            }
        }
        if (buffer_in[buffer_last_ii] == 'R')
        {
            if((buffer_in[buffer_ii] == '0' || buffer_in[buffer_ii] == '1'))
            {
                RB = buffer_in[buffer_ii];
            }
            else
            {
                printf("AZfmPIC:BadDataForRightButtonYB");
                message_incoming = 0;
                fill_string(message_in,'_',MSGSIZE);
            }
        }
        
        buffer_last_ii = buffer_ii;
buffer_ii = (buffer_ii + 1) % BUFSIZE;
//for (int i = 0; i < MSGSIZE-5; i++)
//if (message_incoming ==0)
//{
    if (count >= 3) {
     
        sprintf(message_out, "AZfmM0L0R0YB");
        for (int i = 0; message_out[i] != '\0'; i++) {
            while (!EUSART1_IsTxReady()); // Wait until TX is ready
            EUSART1_Write(message_out[i]);
        }
        __delay_ms(1000);
        count = 0; // Reset the timeout counter after sending
    }
//}
   }
}
                
                
    //        printf("%s,%s",buffer_in,message_in);
           
         
//        if ((sec%3==0) & (sec!=sec_last)){
//            sprintf(message_out,"AZbaPIC: Heartbeat %u YB",sec);
//            send_message(message_out);
////            printf("AZbaPIC: Heartbeat %u YB",sec);
//        }
        
//        if (IO_RC2_GetValue()!=0)
//        {return 1;}
        
        sec_last = sec;
        ms_last = ms;
        __delay_ms(1000);
    }
#include "ssd1306.h"
#include "ssd1306font.h"
#include "mcc_generated_files/i2c_host/mssp1.h"  // Adjust to match your actual I2C include
#include <xc.h> 
#define _XTAL_FREQ 4000000
#define oledAddr SSD1306_I2C_ADDRESS

bool ssd1306_send_command(uint8_t cmd) {
    uint8_t data[2];
    data[0] = 0x00; // Control byte for command
    data[1] = cmd;
    return I2C1_Write(oledAddr, data, 2);
}

bool ssd1306_send_data(uint8_t dataByte) {
    uint8_t data[2];
    data[0] = 0x40; // Control byte for data
    data[1] = dataByte;
    return I2C1_Write(oledAddr, data, 2);
}

bool ssd1306_init() {
    __delay_ms(100); // Let the screen boot

    bool success = true;
    success &= ssd1306_send_command(SSD1306_DISPLAYOFF);
    success &= ssd1306_send_command(SSD1306_SETDISPLAYCLOCKDIV);
    success &= ssd1306_send_command(0x80);
    success &= ssd1306_send_command(SSD1306_SETMULTIPLEX);
    success &= ssd1306_send_command(0x3F);
    success &= ssd1306_send_command(SSD1306_SETDISPLAYOFFSET);
    success &= ssd1306_send_command(0x00);
    success &= ssd1306_send_command(SSD1306_SETSTARTLINE | 0x00);
    success &= ssd1306_send_command(SSD1306_CHARGEPUMP);
    success &= ssd1306_send_command(0x14);
    success &= ssd1306_send_command(SSD1306_MEMORYMODE);
    success &= ssd1306_send_command(0x00);
    success &= ssd1306_send_command(SSD1306_SEGREMAP | 0x1);
    success &= ssd1306_send_command(SSD1306_COMSCANDEC);
    success &= ssd1306_send_command(SSD1306_SETCOMPINS);
    success &= ssd1306_send_command(0x12);
    success &= ssd1306_send_command(SSD1306_SETCONTRAST);
    success &= ssd1306_send_command(0xCF);
    success &= ssd1306_send_command(SSD1306_SETPRECHARGE);
    success &= ssd1306_send_command(0xF1);
    success &= ssd1306_send_command(SSD1306_SETVCOMDETECT);
    success &= ssd1306_send_command(0x40);
    success &= ssd1306_send_command(SSD1306_DISPLAYALLON_RESUME);
    success &= ssd1306_send_command(SSD1306_NORMALDISPLAY);
    success &= ssd1306_send_command(SSD1306_DISPLAYON);

    return success;
}

void ssd1306_test_pattern(void) {
    for (uint8_t page = 0; page < 8; page++) {
        ssd1306_send_command(SSD1306_PAGEADDR);
        ssd1306_send_command(page);
        ssd1306_send_command(7);

        ssd1306_send_command(SSD1306_COLUMNADDR);
        ssd1306_send_command(0);
        ssd1306_send_command(127);

        for (uint8_t i = 0; i < 128; i++) {
            ssd1306_send_data(0xAA); // Pattern: 10101010
        }
    }
}
void ssd1306_draw_char(uint8_t x, uint8_t page, char c) {
    if (c < 32 || c > 127) c = '?';

    ssd1306_send_command(SSD1306_COLUMNADDR);
    ssd1306_send_command(x);
    ssd1306_send_command(x + 5);

    ssd1306_send_command(SSD1306_PAGEADDR);
    ssd1306_send_command(page);
    ssd1306_send_command(page);

    for (uint8_t i = 0; i < 6; i++) {
        ssd1306_send_data(font6x8[c - 32][i]);
    }
}

void ssd1306_draw_string(uint8_t x, uint8_t page, const char* str) {
    while (*str) {
        ssd1306_draw_char(x, page, *str++);
        x += 6;
        if (x + 6 >= 128) break;
    }
}

void ssd1306_clear(void) {
    for (uint8_t page = 0; page < 8; page++) {
        ssd1306_send_command(SSD1306_PAGEADDR);
        ssd1306_send_command(page);
        ssd1306_send_command(page);

        ssd1306_send_command(SSD1306_COLUMNADDR);
        ssd1306_send_command(0);
        ssd1306_send_command(127);

        for (uint8_t col = 0; col < 128; col++) {
            ssd1306_send_data(0x00);
        }
    }
}